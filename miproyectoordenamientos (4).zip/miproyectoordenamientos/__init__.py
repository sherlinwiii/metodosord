from metodosord.selecion import selecion
from metodosord.burbuja import burbuja
from metodosord.insercion import insercion
from metodosord.MENUU import MENUU
