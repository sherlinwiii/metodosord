from metodosord.selecion import selecion
from metodosord.burbuja import burbuja
from metodosord.insercion import insercion
from metodosord.MENUU import MENUU

def main():
    lista = [10, 4, 2, 8, 6, 7]

    print("Lista original:", lista)

    print("\nOrdenada con Selección:")
    print(selecion(lista.copy()))

    print("\nOrdenada con Burbuja:")
    print(burbuja(lista.copy()))

    print("\nOrdenada con Inserción:")
    print(insercion(lista.copy()))

    print("\n¿Deseas abrir el menú interactivo?")
    opcion = input("Escribe 's' para sí: ")

    if opcion.lower() == 's':
        MENUU()
    else:
        print("Programa finalizado.")

if __name__ == "__main__":
    main()


